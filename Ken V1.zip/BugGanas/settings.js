// Mau Buy yang no enc bro ? chat 082332790754 Price ? 10K saja ☕

const fs = require('fs')
const chalk = require('chalk')

global.devNumber = ['6285691430784']
global.name = '𝙆𝙚𝙣𝙣'
global.namebot = '𝙆𝙚𝙣𝙣 V1'

let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.blueBright(`Update File Terbaru ${__filename}`))
delete require.cache[file]
require(file)
})